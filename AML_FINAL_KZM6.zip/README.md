# AML FINAL PROJECT

The .zip file contains:
1 final paper named 'AML_FINAL.pdf'
2 mthods 'Method_1' and 'Method_2' ipynb files. These contain the code for the project.
2 Data sets each divided into trian and test (mitbih_train/test + ptbdb_normal/abnormal) with download links in the paper

All other files are either supporting images, saved model loss values.